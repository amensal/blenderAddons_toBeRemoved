bl_info = {
    "name": "vtools - Instance Tools",
    "author": "Antonio Mendoza",
    "location": "View3D > Panel Tools > Tool Tab",
    "version": (0, 1, 0),
    "blender": (2, 90, 0),
    "warning": "",
    "description": "Tool for operations with instances",
    "category": "Object", 
}


import bpy


def instanceOp_setOrigin():
    
    initialPos = bpy.context.object.location
    bpy.ops.object.mode_set(mode='EDIT')
    initalVertexPos = bpy.context.object.data.vertices[0].co
    bpy.ops.object.mode_set(mode='OBJECT')
    
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='BOUNDS')
    
    lastPos = bpy.context.object.location
    displacement = initialPos - lastPos
    

    bpy.ops.object.select_linked(type="OBDATA")
    for o in bpy.context.selected_objects:
        if o != bpy.context.active_object:
            o.location -= displacement
    
    
        
    
def catchOperatorCallback():
    
    activeOperator = bpy.context.active_operator.name
    if activeOperator!= bpy.context.scene.vtools_lastOperator:
        
        if activeOperator == "Set Origin": 
            print("set Origin")
        elif activeOperator == "Apply Object Transform":
            print("apply transform")
        elif activeOperator == "Apply Modifier":
            print("Apply Modifier")
        elif activeOperator == "Apply All Modifiers":
            print("Apply All Modifiers")


def callback_instanceTools(self, value):
    bpy.ops.vtools.instancetool()


def instanceOp_setOrigin_panel(self, context):
    
    layout = self.layout
    layout.separator()
    layout.operator(VTOOLS_OP_InstanceOp_SetOrigin.bl_idname, text=VTOOLS_OP_InstanceOp_SetOrigin.bl_label)   

def instanceOp_applyInstance_panel(self, context):
    
    layout = self.layout
    layout.separator()
    layout.operator(VTOOLS_OP_InstanceOp_applyTransform.bl_idname, text=VTOOLS_OP_InstanceOp_applyTransform.bl_label)   
                         
    
#------ CLASSES ---#

class VTOOLS_OP_InstanceToolCatcher(bpy.types.Operator):
    bl_idname = "vtools.instancetool"
    bl_label = "Instance Tool Catcher"
    
    def execute(self,context):
        print("ejecutar")
        context.window_manager.modal_handler_add(self)            
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
       
        active = context.scene.vtools_instanceToolActivator
        if active == True:
            catchOperatorCallback()
            print("MODAL")
            return {'PASS_THROUGH'}
        else:
            return {'FINISHED'} 
              
        return {'PASS_THROUGH'}


class VTOOLS_OP_InstanceOp_SetOrigin(bpy.types.Operator):
    bl_idname = "vtools.it_setorigin"
    bl_label = "Instance Op: Set Origin to Cursor"
    
    def instanceOp_setOrigin(self):
        activeObjectName = bpy.context.object.name    
        initialPos = bpy.context.view_layer.objects[activeObjectName].location      
        destPos = bpy.context.scene.cursor.location
        displacement = initialPos - destPos

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='BOUNDS')

        #print("initial pos ", initialPos, "lastPos ", destPos,  "Displacement ", displacement)

        bpy.ops.object.select_linked(type="OBDATA")
        for o in bpy.context.selected_objects:
            if o != bpy.context.active_object:
                o.location -= displacement
    
    def execute(self,context):
        self.instanceOp_setOrigin()          
        return {'FINISHED'}

class VTOOLS_OP_InstanceOp_applyTransform(bpy.types.Operator):
    bl_idname = "vtools.it_applytransform"
    bl_label = "Instance Op: Apply Rot-Scl"
    
    def instanceOp_appplyTransform(self):
        activeObjectName = bpy.context.object.name    
        initialPos = bpy.context.view_layer.objects[activeObjectName].location      
        destPos = bpy.context.scene.cursor.location
        displacement = initialPos - destPos

        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='BOUNDS')

        #print("initial pos ", initialPos, "lastPos ", destPos,  "Displacement ", displacement)

        bpy.ops.object.select_linked(type="OBDATA")
        bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        
        for o in bpy.context.selected_objects:
            if o != bpy.context.active_object:
                o.data = bpy.context.object.data
    
    def execute(self,context):
        self.instanceOp_appplyTransform()          
        return {'FINISHED'}
         

class VTOOLS_PN_instanceTool(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_label = "Instance Tools"
    bl_context = "objectmode"
    bl_category = 'Tool'
    bl_options = {'DEFAULT_CLOSED'}       
    
       
    def draw(self,context):
        
        layout = self.layout
        row = layout.row(align=True)
        row.alignment = 'EXPAND' 
        
        layout.operator(VTOOLS_OP_InstanceOp_SetOrigin.bl_idname, text=VTOOLS_OP_InstanceOp_SetOrigin.bl_label)
        layout.operator(VTOOLS_OP_InstanceOp_applyTransform.bl_idname, text=VTOOLS_OP_InstanceOp_applyTransform.bl_label)
        
        


#------ REGISTER ---#

def register():
    
    from bpy.utils import register_class
    
    #register_class(RNO_PN_RenamePanel)
    #register_class(VTOOLS_PN_instanceTool)
    register_class(VTOOLS_OP_InstanceOp_SetOrigin)
    register_class(VTOOLS_OP_InstanceOp_applyTransform)

    bpy.types.VIEW3D_MT_transform_object.append(instanceOp_setOrigin_panel)
    bpy.types.VIEW3D_MT_object_apply.append(instanceOp_applyInstance_panel)
    
    #bpy.types.Scene.vtools_lastOperator = bpy.props.StringProperty(name="", default='')
    #bpy.types.Scene.vtools_instanceToolActivator = bpy.props.BoolProperty(name='vtoolsinstanceactivator', default=False, update = callback_instanceTools)

          
def unregister():
    
    from bpy.utils import unregister_class
    
    #unregister_class(RNO_PN_RenamePanel)
    #unregister_class(VTOOLS_PN_instanceTool)
    unregister_class(VTOOLS_OP_InstanceOp_SetOrigin)
    unregister_class(VTOOLS_OP_InstanceOp_applyTransform)

    
    #del bpy.types.Scene.vtools_lastOperator
    #del bpy.types.Scene.vtools_instanceToolActivator

    
if __name__ == "__main__":
    register()
    