bl_info = {
    "name": "vtools - Invert Quaternion",
    "author": "Antonio Mendoza",
    "location": "Graph Editor  > Key Menu",
    "version": (0, 1, 0),
    "blender": (2, 90, 0),
    "warning": "",
    "description": "Invert Quaternion to avoid wrong path rotation",
    "category": "Export", 
}

import bpy

#------ OPERATORS ---------# 

class VTOOLS_OP_invertQuaternions(bpy.types.Operator):
    bl_idname = "vtools.invertquaternion"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Invert quaternion to fix rotation"
    
    def invertQuaternion(self):
    
        obj = bpy.context.object
        bon = bpy.context.active_pose_bone
        rotQ = bon.rotation_quaternion
        
        for c in bpy.context.object.animation_data.action.fcurves:
            if c.data_path.find("rotation_quaternion") != -1 and c.data_path.find(bon.name) != -1:
                for k in c.keyframe_points:
                    if k.co[0] == bpy.context.scene.frame_current:
                        k.co[1] *= -1
                        k.handle_right[1] *= -1
                        k.handle_left[1] *= -1
    

    def execute(self, context):
        self.invertQuaternion()
        
        return {"FINISHED"}
    
    
def vtool_menu_invertQuaternionOperator(self, context):
    self.layout.separator()
    self.layout.operator(VTOOLS_OP_invertQuaternions.bl_idname, text="Invert Quaternion")


    
#------ REGISTER ---#

def register():
    
    from bpy.utils import register_class
    
    register_class(VTOOLS_OP_invertQuaternions)
    bpy.types.GRAPH_MT_key.append(vtool_menu_invertQuaternionOperator)
    bpy.types.DOPESHEET_MT_key.append(vtool_menu_invertQuaternionOperator)

          
def unregister():
    
    from bpy.utils import unregister_class
    unregister_class(VTOOLS_OP_invertQuaternions)
    bpy.types.GRAPH_MT_key.remove(vtool_menu_invertQuaternionOperator)
    bpy.types.DOPESHEET_MT_key.remove(vtool_menu_invertQuaternionOperator)

    
if __name__ == "__main__":
    register()